# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['gendiff', 'gendiff.parsers', 'gendiff.scripts']

package_data = \
{'': ['*']}

install_requires = \
['pyyaml>=5.3,<6.0']

entry_points = \
{'console_scripts': ['gendiff = gendiff.scripts.gendiff:main']}

setup_kwargs = {
    'name': 'topolun-gendiff',
    'version': '0.3.0',
    'description': 'Check for diiferences in 2 files',
    'long_description': None,
    'author': 'Topolun',
    'author_email': 'vik83tu@yandex.ru',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.6,<4.0',
}


setup(**setup_kwargs)
