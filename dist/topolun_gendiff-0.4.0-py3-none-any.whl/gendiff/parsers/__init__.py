from gendiff.parsers.yaml import recieve_yaml  # noqa: F401
from gendiff.parsers.json import recieve_json  # noqa: F401
