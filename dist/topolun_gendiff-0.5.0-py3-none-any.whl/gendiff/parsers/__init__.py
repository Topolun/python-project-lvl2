from gendiff.parsers.files import compare  # noqa: F401
